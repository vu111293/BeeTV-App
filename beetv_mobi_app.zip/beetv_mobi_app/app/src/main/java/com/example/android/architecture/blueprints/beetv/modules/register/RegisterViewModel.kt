package com.example.android.architecture.blueprints.beetv.modules.register

import androidx.lifecycle.ViewModel

class RegisterViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}