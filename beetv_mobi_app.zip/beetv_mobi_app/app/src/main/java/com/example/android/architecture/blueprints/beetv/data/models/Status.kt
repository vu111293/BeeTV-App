package com.example.android.architecture.blueprints.beetv.data.models

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}