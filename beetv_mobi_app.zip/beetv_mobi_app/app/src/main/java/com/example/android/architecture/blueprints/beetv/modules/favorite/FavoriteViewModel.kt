package com.example.android.architecture.blueprints.beetv.modules.favorite

import androidx.lifecycle.ViewModel

class FavoriteViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}