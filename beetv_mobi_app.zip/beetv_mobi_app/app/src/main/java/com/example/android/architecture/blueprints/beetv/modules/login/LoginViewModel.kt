package com.example.android.architecture.blueprints.beetv.modules.login

import androidx.lifecycle.ViewModel

class LoginViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}