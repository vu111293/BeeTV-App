package com.example.android.architecture.blueprints.beetv.modules.search

import androidx.lifecycle.ViewModel

class SearchViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}